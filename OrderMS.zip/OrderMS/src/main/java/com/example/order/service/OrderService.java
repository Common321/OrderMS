package com.example.order.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.order.dto.CartDTO;
import com.example.order.dto.OrderTableDTO;
import com.example.order.entity.Order;
import com.example.order.repository.OrderRepository;


@Service
public class OrderService {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	OrderRepository orderRepo;
	
	public List<OrderTableDTO> getAllOrders() {
		List<Order> orders = orderRepo.findAll();
		List<OrderTableDTO> orderDtos = new ArrayList<OrderTableDTO>();
		for (Order order : orders) {
			OrderTableDTO orderDto = OrderTableDTO.valueOf(order);
			orderDtos.add(orderDto);
			logger.info("order details : {}", order.getStatus());
		}
		logger.info("order details : {}", orders);
		return orderDtos;
	}
	
	public String makeOrder(OrderTableDTO orderDTO)
	{
					
		//logger.info("Creation request to make an order {}", cart);
		logger.info("Creation request to make an order {}", orderDTO);
		Order order = orderDTO.CreateEntity();
		orderRepo.save(order);
		return "Order Placed Successfully";
		
	}
	
	public OrderTableDTO getSpecificOrder(int orderId) {
		logger.info("order details : {}", orderId);
		return OrderTableDTO.valueOf(orderRepo.findByOrderId(orderId));
	}
}
