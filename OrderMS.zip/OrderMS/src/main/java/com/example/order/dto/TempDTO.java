package com.example.order.dto;

import java.time.LocalDateTime;

import com.example.order.entity.Order;
import com.example.order.entity.StatusValues;

public class TempDTO {
	 Integer buyerId;
	 String address;
	 String amount;
	public Integer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
}
