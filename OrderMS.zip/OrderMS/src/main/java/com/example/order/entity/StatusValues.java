package com.example.order.entity;

public enum StatusValues {
	none, orderPlaced, orderCancelled
}
