package com.example.order.entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class KeyComp implements Serializable {
		Integer buyerId;
		Integer prodId;
}
